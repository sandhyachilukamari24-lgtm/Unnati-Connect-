# Unnati Connect 1.0 — Android source project

A native Android starter app for Unnati Coaching Classes. It uses Kotlin, Jetpack Compose and Firebase Authentication, Firestore and Storage.

## Included
- Separate Admin and Student sign-in roles
- Student profiles with parent mobile number, email, batch and monthly fee
- Monthly fee records in INR with Paid/Pending status
- Daily attendance records
- Study-material upload to Firebase Storage and publishing to students
- Institute details and backup contact fields
- Export/share backup summary
- Student views for own profile, fees, attendance and published materials

## Important: Firebase setup is required
This source project is not a ready-to-install APK. Firebase is needed for secure multi-device accounts and shared data.

1. Install Android Studio on a computer and open this project folder.
2. Create a Firebase project at https://console.firebase.google.com/
3. Add an Android app with package name `com.unnaticoaching.connect`.
4. Download `google-services.json` and put it in the `app/` folder.
5. Enable Email/Password in Firebase Authentication.
6. Create a Cloud Firestore database and enable Firebase Storage.
7. Publish the included `firestore.rules` in Firestore Rules and `storage.rules` in Storage Rules.
8. Build and run the app.

## Create the first admin
For security, public sign-up does not grant admin rights.
1. Create the first account using the app's sign-up option.
2. In Firebase Console > Firestore, create collection `users`.
3. Create a document whose ID is that account's Firebase Authentication UID.
4. Set fields: `role` (string) = `admin`; `name` (string) = `Institute Admin`.
5. Sign out and sign in again.

## Student accounts
1. Student creates an account using their email.
2. In Firestore, create `users/{student-auth-uid}` with `role: "student"` and `name`.
3. Create `students/{same-student-auth-uid}` with `name`, `email`, `parentPhone`, `batch`, and `monthlyFee`.
4. The student will then see their own data. Fee and attendance records must use this same UID in their `studentId` field.

## Admin student records
The in-app Add Student form creates a student profile document with an auto-generated ID. To link a student's login, use that student's Firebase Auth UID as the student document ID (create/link the record in Firebase Console). The Fees and Attendance forms ask for the student profile document ID. A future production iteration should add an in-app student-account invitation/linking workflow.

## Current limitations / next production steps
- Fee reminders are not automatically sent. Use parent phone details with a future approved SMS/WhatsApp provider integration; always review messages before sending.
- Monthly fee schedule entries are created by the admin; recurring auto-generation is not enabled.
- Backup export currently shares a readable student/fee summary, not a full restorable database archive. Download and protect complete Firestore/Storage backups before production use.
- Add edit/delete workflows, batch creation screens, payment receipt generation, stronger validation, audit logs, and automated backup before using with real student records.
- Keep Firebase rules deployed. Never put service-account credentials or private keys in the Android app.


## Build APK from an Android phone (GitHub Actions)
1. Create a **private** GitHub repository in your mobile browser.
2. Upload the contents of this project ZIP into the repository (not the ZIP itself).
3. Upload your `google-services.json` into the `app/` folder.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build Unnati Connect APK**.
6. Tap **Run workflow** if it has not started automatically.
7. When the run completes, open it and download the `Unnati-Connect-debug-apk` artifact.
8. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone.

Keep the repository private because it contains project configuration and institute app source. Firebase client configuration is not a substitute for security rules; publish the included Firestore and Storage rules before adding real student information.
