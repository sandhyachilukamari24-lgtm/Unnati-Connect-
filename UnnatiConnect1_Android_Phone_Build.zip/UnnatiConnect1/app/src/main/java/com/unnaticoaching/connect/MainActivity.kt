package com.unnaticoaching.connect

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { UnnatiApp() } }
    }
}

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }
private val storage by lazy { FirebaseStorage.getInstance() }

@Composable
fun UnnatiApp() {
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(user) {
        if (user != null) {
            db.collection("users").document(user!!.uid).get()
                .addOnSuccessListener { doc ->
                    role = doc.getString("role") ?: ""
                    displayName = doc.getString("name") ?: user!!.email.orEmpty()
                    if (role !in listOf("admin", "student")) error = "Your account role is not configured. Ask the institute administrator."
                }
                .addOnFailureListener { error = it.localizedMessage ?: "Could not load account." }
        } else { role = ""; displayName = "" }
    }

    if (user == null) {
        LoginScreen(error) { email, password, isRegister ->
            error = ""
            val task = if (isRegister) auth.createUserWithEmailAndPassword(email, password)
                       else auth.signInWithEmailAndPassword(email, password)
            task.addOnSuccessListener { user = auth.currentUser }
                .addOnFailureListener { error = it.localizedMessage ?: "Sign-in failed." }
        }
    } else if (role == "admin" || role == "student") {
        HomeScreen(role, displayName) {
            auth.signOut(); user = null
        }
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Text(error.ifBlank { "Loading your account…" }, modifier = Modifier.padding(16.dp))
                TextButton(onClick = { auth.signOut(); user = null }) { Text("Sign out") }
            }
        }
    }
}

@Composable
fun LoginScreen(error: String, onAuth: (String, String, Boolean) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card(shape = RoundedCornerShape(24.dp), elevation = CardDefaults.cardElevation(5.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("UNNATI CONNECT", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Unnati Coaching Classes", color = MaterialTheme.colorScheme.primary)
                Text(if (register) "Create a student account" else "Sign in to continue")
                OutlinedTextField(email, { email = it }, label = { Text("Email address") }, singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                Button(onClick = { onAuth(email.trim(), password, register) }, modifier = Modifier.fillMaxWidth(),
                    enabled = email.contains("@") && password.length >= 6) {
                    Text(if (register) "Create account" else "Sign in")
                }
                TextButton(onClick = { register = !register }) {
                    Text(if (register) "Already have an account? Sign in" else "New student? Create account")
                }
                Text("Student accounts must be linked to a student profile by the institute.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun HomeScreen(role: String, name: String, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf("Dashboard") }
    val tabs = if (role == "admin") listOf("Dashboard", "Students", "Fees", "Attendance", "Materials", "Settings")
               else listOf("Dashboard", "My Fees", "Attendance", "Materials", "Institute")
    Scaffold(
        topBar = {
            TopAppBarCompat(title = "Unnati Connect", subtitle = "Welcome, $name", onLogout = onLogout)
        },
        bottomBar = {
            NavigationBar {
                val visible = tabs.take(5)
                visible.forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(iconFor(item), contentDescription = item) },
                        label = { Text(item, maxLines = 1) })
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (role == "admin" && tab == "Dashboard") AdminDashboard()
            else if (role == "admin" && tab == "Students") StudentsScreen()
            else if (role == "admin" && tab == "Fees") FeesScreen()
            else if (role == "admin" && tab == "Attendance") AttendanceScreen()
            else if (role == "admin" && tab == "Materials") MaterialsScreen(true)
            else if (role == "admin" && tab == "Settings") SettingsScreen()
            else if (role == "student" && tab == "Dashboard") StudentDashboard()
            else if (role == "student" && tab == "My Fees") StudentFees()
            else if (role == "student" && tab == "Attendance") StudentAttendance()
            else if (role == "student" && tab == "Materials") MaterialsScreen(false)
            else InstituteScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, subtitle: String, onLogout: () -> Unit) {
    TopAppBar(title = { Column { Text(title); Text(subtitle, style = MaterialTheme.typography.labelSmall) } },
        actions = { IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Sign out") } })
}

@Composable
fun Page(title: String, description: String = "", content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (description.isNotBlank()) Text(description, style = MaterialTheme.typography.bodyMedium)
        content()
    }
}

@Composable
fun AdminDashboard() {
    var students by remember { mutableStateOf("—") }
    var fees by remember { mutableStateOf("—") }
    var pending by remember { mutableStateOf("—") }
    LaunchedEffect(Unit) {
        db.collection("students").get().addOnSuccessListener { students = it.size().toString() }
        db.collection("fees").whereEqualTo("status", "Paid").get().addOnSuccessListener {
            fees = "₹" + it.documents.sumOf { d -> d.getDouble("amount") ?: 0.0 }.toLong()
        }
        db.collection("fees").whereEqualTo("status", "Pending").get().addOnSuccessListener {
            pending = "₹" + it.documents.sumOf { d -> d.getDouble("amount") ?: 0.0 }.toLong()
        }
    }
    Page("Institute Dashboard", "Quick overview of Unnati Coaching Classes") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Students", students, Modifier.weight(1f))
            StatCard("Collected", fees, Modifier.weight(1f))
        }
        StatCard("Pending fees", pending, Modifier.fillMaxWidth())
        Text("Use the tabs below to manage students, fees, attendance and learning materials.")
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StudentsScreen() {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var parentPhone by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var list by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    fun refresh() { db.collection("students").get().addOnSuccessListener { snap ->
        list = snap.documents.map { mapOf("id" to it.id) + (it.data ?: emptyMap()) }
    } }
    LaunchedEffect(Unit) { refresh() }
    Page("Student Management", "Add student profiles and parent contact details") {
        OutlinedTextField(name, { name = it }, label = { Text("Student full name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Student email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(parentPhone, { parentPhone = it }, label = { Text("Parent mobile number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(batch, { batch = it }, label = { Text("Batch name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(fee, { fee = it }, label = { Text("Monthly fee (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (name.isNotBlank() && batch.isNotBlank()) {
                val data = hashMapOf<String, Any>("name" to name, "email" to email,
                    "parentPhone" to parentPhone, "batch" to batch,
                    "monthlyFee" to (fee.toDoubleOrNull() ?: 0.0), "createdAt" to System.currentTimeMillis())
                db.collection("students").add(data).addOnSuccessListener {
                    name=""; email=""; parentPhone=""; batch=""; fee=""; note="Student saved"; refresh()
                }.addOnFailureListener { note = it.localizedMessage ?: "Save failed" }
            } else note = "Student name and batch are required."
        }, modifier = Modifier.fillMaxWidth()) { Text("Add student") }
        if (note.isNotBlank()) Text(note)
        Divider()
        Text("Registered students (${list.size})", fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { s ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(s["name"]?.toString() ?: "Student", fontWeight = FontWeight.Bold)
                        Text("Batch: ${s["batch"] ?: "—"}  •  Fee: ₹${s["monthlyFee"] ?: "0"}")
                        Text("Parent: ${s["parentPhone"] ?: "Not added"}")
                    }
                }
            }
        }
    }
}

@Composable
fun FeesScreen() {
    var studentId by remember { mutableStateOf("") }
    var month by remember { mutableStateOf(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())) }
    var amount by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Pending") }
    var message by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    fun refresh() { db.collection("fees").get().addOnSuccessListener { rows = it.documents.map { d -> mapOf("id" to d.id) + (d.data ?: emptyMap()) } } }
    LaunchedEffect(Unit) { refresh() }
    Page("Monthly Fees", "Create monthly dues and record payments. Student ID is the profile document ID.") {
        OutlinedTextField(studentId, { studentId=it }, label={ Text("Student profile ID") }, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(month, { month=it }, label={ Text("Fee month (e.g. November 2026)") }, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount=it }, label={ Text("Amount (₹)") }, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("Status: ")
            FilterChip(selected=status=="Pending", onClick={status="Pending"}, label={Text("Pending")})
            Spacer(Modifier.width(8.dp))
            FilterChip(selected=status=="Paid", onClick={status="Paid"}, label={Text("Paid")})
        }
        Button(onClick={
            val a=amount.toDoubleOrNull()
            if(studentId.isNotBlank() && a!=null) {
                db.collection("fees").add(mapOf("studentId" to studentId.trim(),"month" to month.trim(),
                    "amount" to a,"status" to status,"updatedAt" to System.currentTimeMillis()))
                    .addOnSuccessListener { message="Fee record saved"; amount=""; refresh() }
                    .addOnFailureListener { message=it.localizedMessage ?: "Could not save" }
            } else message="Enter a student ID and valid amount."
        }, modifier=Modifier.fillMaxWidth()) { Text("Save fee record") }
        if(message.isNotBlank()) Text(message)
        Divider()
        Text("Fee records", fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            items(rows) { r ->
                Card { Column(Modifier.padding(12.dp)) {
                    Text("${r["month"] ?: ""} • ₹${r["amount"] ?: ""}", fontWeight=FontWeight.Bold)
                    Text("Student: ${r["studentId"] ?: ""}  |  ${r["status"] ?: ""}")
                } }
            }
        }
    }
}

@Composable
fun AttendanceScreen() {
    var studentId by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var present by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("") }
    Page("Attendance", "Record daily attendance for each student") {
        OutlinedTextField(studentId, { studentId=it }, label={Text("Student profile ID")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(batch, { batch=it }, label={Text("Batch")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(date, { date=it }, label={Text("Date (YYYY-MM-DD)")}, modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically) {
            FilterChip(selected=present,onClick={present=true},label={Text("Present")})
            Spacer(Modifier.width(8.dp))
            FilterChip(selected=!present,onClick={present=false},label={Text("Absent")})
        }
        Button(onClick={
            if(studentId.isNotBlank() && batch.isNotBlank()) {
                db.collection("attendance").add(mapOf("studentId" to studentId.trim(),"batch" to batch.trim(),
                    "date" to date.trim(),"status" to if(present) "Present" else "Absent",
                    "markedAt" to System.currentTimeMillis()))
                    .addOnSuccessListener { message="Attendance saved" }
                    .addOnFailureListener { message=it.localizedMessage ?: "Save failed" }
            } else message="Student ID and batch are required."
        },modifier=Modifier.fillMaxWidth()) { Text("Save attendance") }
        if(message.isNotBlank()) Text(message)
    }
}

@Composable
fun MaterialsScreen(admin: Boolean) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var docs by remember { mutableStateOf(listOf<Map<String,Any>>()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null && admin) {
            val path = "study-materials/${System.currentTimeMillis()}_${uri.lastPathSegment ?: "file"}"
            storage.reference.child(path).putFile(uri).addOnSuccessListener {
                storage.reference.child(path).downloadUrl.addOnSuccessListener { download ->
                    db.collection("materials").add(mapOf("title" to title.ifBlank { "Study material" },
                        "batch" to batch.ifBlank { "All batches" }, "downloadUrl" to download.toString(),
                        "storagePath" to path, "createdAt" to System.currentTimeMillis()))
                        .addOnSuccessListener { note="Material published"; refreshMaterials { docs=it } }
                        .addOnFailureListener { note=it.localizedMessage ?: "Could not save material record" }
                }
            }.addOnFailureListener { note=it.localizedMessage ?: "Upload failed" }
        }
    }
    fun noop() {}
    LaunchedEffect(Unit) { refreshMaterials { docs=it } }
    Page("Study Materials", if(admin) "Upload and publish notes, PDFs and assignments for batches" else "Materials published by your institute") {
        if(admin) {
            OutlinedTextField(title,{title=it},label={Text("Material title")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(batch,{batch=it},label={Text("Batch (or All batches)")},modifier=Modifier.fillMaxWidth())
            Button(onClick={ picker.launch("*/*") },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile,null); Spacer(Modifier.width(8.dp)); Text("Choose file and publish") }
            Text("Choose a PDF, image or document from your phone.")
        }
        if(note.isNotBlank()) Text(note)
        Divider()
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(docs) { item ->
                Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item["title"]?.toString() ?: "Study material", fontWeight=FontWeight.Bold)
                        Text("Batch: ${item["batch"] ?: "All batches"}")
                    }
                    TextButton(onClick={
                        val url=item["downloadUrl"]?.toString()
                        if(url!=null) context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }) { Text("Open") }
                } }
            }
        }
    }
}

fun refreshMaterials(done: (List<Map<String,Any>>) -> Unit) {
    db.collection("materials").get().addOnSuccessListener { snap ->
        done(snap.documents.map { it.data ?: emptyMap() })
    }
}

@Composable
fun StudentDashboard() {
    val uid = auth.currentUser?.uid ?: ""
    var student by remember { mutableStateOf<Map<String,Any>>(emptyMap()) }
    LaunchedEffect(uid) {
        db.collection("students").document(uid).get().addOnSuccessListener { student=it.data ?: emptyMap() }
    }
    Page("Student Dashboard", "Your learning space") {
        Text("Welcome, ${student["name"] ?: auth.currentUser?.email.orEmpty()}", style=MaterialTheme.typography.titleLarge)
        StatCard("Your batch", student["batch"]?.toString() ?: "Profile not linked")
        StatCard("Monthly fee", "₹${student["monthlyFee"] ?: "—"}")
        Text("Use the tabs to view your fees, attendance and study materials.")
    }
}

@Composable
fun StudentFees() {
    val uid=auth.currentUser?.uid ?: ""
    var rows by remember { mutableStateOf(listOf<Map<String,Any>>()) }
    LaunchedEffect(uid) { db.collection("fees").whereEqualTo("studentId",uid).get().addOnSuccessListener {
        rows=it.documents.map { d -> d.data ?: emptyMap() }
    } }
    Page("My Fees", "Your monthly fee schedule and payment status") {
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(rows) { r -> Card { Column(Modifier.padding(12.dp)) {
                Text(r["month"]?.toString() ?: "Month",fontWeight=FontWeight.Bold)
                Text("₹${r["amount"] ?: "—"} • ${r["status"] ?: "Pending"}")
            } } }
        }
        if(rows.isEmpty()) Text("No fee records found yet.")
    }
}

@Composable
fun StudentAttendance() {
    val uid=auth.currentUser?.uid ?: ""
    var rows by remember { mutableStateOf(listOf<Map<String,Any>>()) }
    LaunchedEffect(uid) { db.collection("attendance").whereEqualTo("studentId",uid).get().addOnSuccessListener {
        rows=it.documents.map { d -> d.data ?: emptyMap() }
    } }
    Page("My Attendance", "Your attendance records") {
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(rows) { r -> Card { Column(Modifier.padding(12.dp)) {
                Text(r["date"]?.toString() ?: "Date",fontWeight=FontWeight.Bold)
                Text("${r["status"] ?: ""} • ${r["batch"] ?: ""}")
            } } }
        }
        if(rows.isEmpty()) Text("No attendance records found yet.")
    }
}

@Composable
fun SettingsScreen() {
    val context= LocalContext.current
    var institute by remember { mutableStateOf("Unnati Coaching Classes") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var backupPhone by remember { mutableStateOf("") }
    var backupEmail by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Page("Institute & Backup Settings", "Keep institute and recovery contact details updated") {
        OutlinedTextField(institute,{institute=it},label={Text("Institute name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(address,{address=it},label={Text("Institute address")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(phone,{phone=it},label={Text("Institute mobile number")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(email,{email=it},label={Text("Institute email")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(backupPhone,{backupPhone=it},label={Text("Backup mobile number")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(backupEmail,{backupEmail=it},label={Text("Backup email")},modifier=Modifier.fillMaxWidth())
        Button(onClick={
            db.collection("settings").document("institute").set(mapOf("name" to institute,"address" to address,
                "phone" to phone,"email" to email,"backupPhone" to backupPhone,"backupEmail" to backupEmail))
                .addOnSuccessListener { message="Institute settings saved" }
                .addOnFailureListener { message=it.localizedMessage ?: "Save failed" }
        },modifier=Modifier.fillMaxWidth()) { Text("Save institute details") }
        Button(onClick={
            db.collection("students").get().addOnSuccessListener { students ->
                db.collection("fees").get().addOnSuccessListener { fees ->
                    val export = buildString {
                        append("UNNATI CONNECT BACKUP\nStudents: ${students.size()}\nFees: ${fees.size()}\n\n")
                        students.documents.forEach { append("STUDENT: ${it.id} | ${it.data}\n") }
                        fees.documents.forEach { append("FEE: ${it.id} | ${it.data}\n") }
                    }
                    val intent=Intent(Intent.ACTION_SEND).apply {
                        type="text/plain"; putExtra(Intent.EXTRA_SUBJECT,"Unnati Connect data backup")
                        putExtra(Intent.EXTRA_TEXT,export)
                    }
                    context.startActivity(Intent.createChooser(intent,"Save or send backup"))
                }
            }
        },modifier=Modifier.fillMaxWidth()) { Text("Export backup / share") }
        if(message.isNotBlank()) Text(message)
        Text("Backup export currently includes student and fee summaries. Store exported files securely; this is not an automatic cloud backup.",style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun InstituteScreen() {
    var data by remember { mutableStateOf<Map<String,Any>>(emptyMap()) }
    LaunchedEffect(Unit) { db.collection("settings").document("institute").get().addOnSuccessListener { data=it.data ?: emptyMap() } }
    Page("Institute Details", "Contact and institute information") {
        Text(data["name"]?.toString() ?: "Unnati Coaching Classes",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        Text(data["address"]?.toString() ?: "Address not published")
        Text("Mobile: ${data["phone"] ?: "Not available"}")
        Text("Email: ${data["email"] ?: "Not available"}")
    }
}

@Composable
fun iconFor(tab: String) = when(tab) {
    "Students" -> Icons.Default.Groups
    "Fees", "My Fees" -> Icons.Default.AccountBalanceWallet
    "Attendance" -> Icons.Default.EventAvailable
    "Materials" -> Icons.Default.MenuBook
    "Settings" -> Icons.Default.Settings
    "Institute" -> Icons.Default.School
    else -> Icons.Default.Dashboard
}
